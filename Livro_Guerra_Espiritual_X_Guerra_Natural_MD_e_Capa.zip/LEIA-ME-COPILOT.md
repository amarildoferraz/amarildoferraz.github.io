# Pacote do livro para o Copilot

Este pacote contém os dois arquivos necessários para apresentar a obra no site:

- `Guerra_Espiritual_X_Guerra_Natural_Amarildo_Adao_Ferraz.md` — conteúdo integral do livro em Markdown.
- `capa-guerra-espiritual-x-guerra-natural.png` — capa vertical oficial, usada também na primeira página do manuscrito Word.

## Orientação para o Copilot

Use o arquivo Markdown como fonte do conteúdo e a imagem PNG como capa. Integre o livro ao site existente, respeitando a estrutura e o padrão visual já utilizados no projeto. Preserve o texto, os títulos, a ordem dos capítulos, as referências bíblicas e a dedicatória. Não resuma nem reescreva o manuscrito. Garanta que o caminho da imagem da capa seja ajustado corretamente no site e que a página funcione em computadores e celulares.
